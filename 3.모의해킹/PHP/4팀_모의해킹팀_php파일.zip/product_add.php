<?php
include 'db.php';
include 'header.php';

// [모의해킹 진단 포인트: 불완전한 권한 검증]
// 세션의 user_type이 관리자(A)인지 검증하는 로직이 누락되어 있거나 느슨하여, 
// 공격자가 주소창에 직접 입력해 들어와 상품을 무단 등록할 수 있는 취약점 구역입니다.
?>

<div class="container my-5" style="min-height: 75vh;">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm p-4" style="border-radius: 16px;">
                <h4 class="fw-bold text-dark mb-4 border-start border-4 border-indigo ps-2" style="border-color: #6f42c1 !important;">
                    ✨ 딩동몰 신규 상품 등록 (관리자용)
                </h4>
                
                <form action="admin_product_add_proc.php" method="POST" enctype="multipart/form-data">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label small fw-bold text-muted">카테고리 선택</label>
                            <select name="product_category" class="form-select border-muted" style="border-radius: 8px;" required>
                                <option value="feed">사료 (feed)</option>
                                <option value="pad">배변패드 (pad)</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label small fw-bold text-muted">상품 가격 (원)</label>
                            <input type="number" name="product_price" class="form-control border-muted" placeholder="예: 15000" style="border-radius: 8px;" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label small fw-bold text-muted">상품 이름</label>
                            <input type="text" name="product_name" class="form-control border-muted" placeholder="영양만점 딩동이 사료" style="border-radius: 8px;" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label small fw-bold text-muted">상품 대표 이미지</label>
                            <input type="file" name="product_image" class="form-control border-muted" style="border-radius: 8px;">
                            <div class="form-text text-muted">※ 모의해킹 실습을 위해 확장자 검증이 누락되어 있습니다 (웹쉘 업로드 훈련용).</div>
                        </div>
                        <div class="col-12 text-end mt-4">
                            <button type="button" class="btn btn-light me-2" onclick="history.back();" style="border-radius: 8px;">취소</button>
                            <button type="submit" class="btn text-white px-4" style="background-color: #6f42c1; border-radius: 8px;">
                                상품 등록하기 🐾
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
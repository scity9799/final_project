<?php
include 'db.php';
include 'header.php';

// [실습용 설정] 로그인 상태 체크
if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('로그인이 필요한 서비스입니다, 왈!'); location.href='login.php';</script>";
    exit;
}

$session_id = $_SESSION['user_id'];

// 사용자의 장바구니 리스트와 상품 정보 조인 조회
// (보안 진단: 세션 아이디가 쿼리에 직접 결합되는 구조를 시연할 수 있음)
$sql = "SELECT c.cart_id, c.product_id, c.product_count, p.product_name, p.product_price, p.product_image, p.product_category 
        FROM ddm_cart c 
        JOIN ddm_product p ON c.product_id = p.product_id 
        WHERE c.user_id = '$session_id' 
        ORDER BY c.cart_id DESC";
$result = mysqli_query($conn, $sql);

$total_cart_price = 0; // 총 결제 예정 금액 변수
?>

<div class="container my-5" style="min-height: 75vh;">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="text-dark fw-bold border-start border-4 border-indigo ps-2" style="border-color: #6f42c1 !important;">
            🛒 내 장바구니 바구니
        </h3>
        <span class="text-muted">담은 상품 <?=mysqli_num_rows($result)?>개</span>
    </div>

    <div class="row g-4">
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm p-4" style="border-radius: 16px;">
                <div class="table-responsive">
                    <table class="table align-middle mb-0">
                        <thead class="text-muted small text-uppercase" style="background-color: #fcfbff;">
                            <tr>
                                <th class="py-3 border-0" style="width: 45%;">상품 정보</th>
                                <th class="py-3 border-0 text-center" style="width: 15%;">가격</th>
                                <th class="py-3 border-0 text-center" style="width: 20%;">수량</th>
                                <th class="py-3 border-0 text-center" style="width: 15%;">합계</th>
                                <th class="py-3 border-0 text-center" style="width: 5%;"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if (mysqli_num_rows($result) > 0) {
                                while ($row = mysqli_fetch_assoc($result)) {
                                    $subtotal = $row['product_price'] * $row['product_count'];
                                    $total_cart_price += $subtotal;
                                    $img_path = !empty($row['product_image']) ? $row['product_image'] : 'https://via.placeholder.com/100x100/f3f0ff/6f42c1?text=Product';
                            ?>
                                    <tr style="border-bottom: 1px solid #f1effb;">
                                        <td class="py-3">
                                            <div class="d-flex align-items-center gap-3">
                                                <img src="<?=$img_path?>" alt="" style="width: 70px; height: 70px; object-fit: cover; border-radius: 8px;">
                                                <div>
                                                    <span class="badge mb-1" style="background-color: #ebe5fc; color: #6f42c1; font-size: 0.75rem;">
                                                        <?=$row['product_category'] == 'feed' ? '사료' : '배변패드'?>
                                                    </span>
                                                    <h6 class="fw-bold text-dark m-0" style="font-size: 0.95rem;"><?=htmlspecialchars($row['product_name'])?></h6>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="text-center py-3 text-muted">
                                            <?=number_format($row['product_price'])?>원
                                        </td>
                                        <td class="text-center py-3">
                                            <form action="cart_update.php" method="POST" class="d-flex justify-content-center align-items-center gap-1">
                                                <input type="hidden" name="cart_id" value="<?=$row['cart_id']?>">
                                                <input type="number" name="product_count" class="form-control form-control-sm text-center border-muted" 
                                                       value="<?=$row['product_count']?>" style="width: 60px; border-radius: 6px;">
                                                <button type="submit" class="btn btn-sm btn-light" style="color: #6f42c1; border-color: #e1dbf7;">변경</button>
                                            </form>
                                        </td>
                                        <td class="text-center py-3 fw-bold text-dark">
                                            <?=number_format($subtotal)?>원
                                        </td>
                                        <td class="text-center py-3">
                                            <a href="cart_delete.php?cart_id=<?=$row['cart_id']?>" class="text-decoration-none text-muted fs-5 transition-danger" onclick="return confirm('정말 삭제하시겠습니까, 왈?');">
                                                ❌
                                            </a>
                                        </td>
                                    </tr>
                            <?php
                                }
                            } else {
                                echo '<tr><td colspan="5" class="text-center py-5 text-muted">장바구니가 비어있습니다, 왈! 🐶<br><a href="shop_list.php" class="btn btn-sm text-white mt-3" style="background-color: #6f42c1;">상품 보러가기</a></td></tr>';
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card border-0 shadow-sm p-4 text-dark" style="border-radius: 16px; background-color: #fdfcff; border: 1px solid #f1effb !important;">
                <h5 class="fw-bold mb-4">💳 결제 금액 정보</h5>
                
                <div class="d-flex justify-content-between mb-2">
                    <span class="text-muted">총 상품 금액</span>
                    <span class="fw-bold"><?=number_format($total_cart_price)?>원</span>
                </div>
                <div class="d-flex justify-content-between mb-3">
                    <span class="text-muted">배송비</span>
                    <span class="text-success fw-bold">무료 배송 🐾</span>
                </div>
                
                <hr style="border-color: #e1dbf7;">
                
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <span class="fw-bold fs-5">최종 결제 금액</span>
                    <span class="fw-bold fs-4 text-danger"><?=number_format($total_cart_price)?>원</span>
                </div>

                <form action="order_process.php" method="POST">
                    <input type="hidden" name="total_amount" value="<?=$total_cart_price?>">
                    <button type="submit" class="btn text-white w-100 py-3 fw-bold" 
                            style="background-color: #6f42c1; border-radius: 12px; font-size: 1.1rem;" 
                            <?=mysqli_num_rows($result) == 0 ? 'disabled' : ''?>>
                        주문하기 (원클릭 결제) 🦴
                    </button>
                </form>
                <p class="text-muted small text-center mt-3 mb-0">딩동몰은 별도의 결제창 없이 즉시 주문 처리가 완료됩니다.</p>
            </div>
        </div>
    </div>
</div>

<style>
.transition-danger:hover {
    color: #dc3545 !important;
}
</style>

<?php
include 'footer.php';
?>
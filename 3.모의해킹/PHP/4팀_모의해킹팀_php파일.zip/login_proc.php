<?php
include 'db.php'; // 공통 DB 연결 및 session_start() 포함

// 입력값 수집
$user_id = $_POST['user_id'] ?? '';
$user_pw = $_POST['user_pw'] ?? '';

/**
 * [핵심 요구사항 반영 구역]
 * 체크박스가 선택되어 'A'가 넘어오면 관리자('A'), 
 * 아무것도 체크 안 해서 값이 비어있으면 기본 보호소 회원('S')으로 세팅합니다.
 */
$user_type = (isset($_POST['user_type']) && $_POST['user_type'] === 'A') ? 'A' : 'S';

if (empty($user_id) || empty($user_pw)) {
    echo "<script>alert('아이디와 비밀번호를 모두 입력해 주세요, 왈!'); history.back();</script>";
    exit;
}

/**
 * 🛑 [모의해킹 훈련용 취약점 구역] SQL Injection & Session Fixation 
 * 입력값 검증(Prepared Statement) 없이 동적 쿼리로 조립되어 
 * ' OR '1'='1 비밀번호 우회 공격 등이 통하는 상태입니다.
 */
$query = "SELECT * FROM ddd_user WHERE user_id = '$user_id' AND user_password = '$user_pw' AND user_type = '$user_type'";
$result = mysqli_query($conn, $query);

if ($result && mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    
    // 인증 성공 -> 세션 바인딩
    $_SESSION['user_no']   = $row['user_number'];
    $_SESSION['user_id']   = $row['user_id'];
    $_SESSION['user_name'] = $row['user_name'];
    $_SESSION['user_type'] = $row['user_type']; // 'S'(보호소) 또는 'A'(관리자) 가 저장됨

    echo "<script>alert('🐾 " . $row['user_name'] . "님, 딩동몰에 오신 것을 환영합니다!'); location.href='main.php';</script>";
} else {
    // 인증 실패
    echo "<script>alert('❌ 일치하는 회원 정보가 없습니다. 로그인 타입을 다시 확인해 주세요, 왈!'); history.back();</script>";
}
?>
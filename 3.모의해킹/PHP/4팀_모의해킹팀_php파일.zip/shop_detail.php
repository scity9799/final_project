<?php
include 'db.php';     // DB 연결 환경 및 session_start() 포함
include 'header.php'; // 공통 헤더 조립 (요청하신 검색창 제거 버전)

// 🛑 [모의해킹 진단 포인트] 파라미터 변조(IDOR) 및 SQL Injection 유도를 위해 입력값 정제 없이 수집
$product_id = $_GET['id'] ?? '';

if (empty($product_id)) {
    echo "<script>alert('올바르지 않은 접근입니다, 왈!'); location.href='shop_list.php';</script>";
    exit;
}

/**
 * 🔍 동적 DB 데이터 연동 구역 (하드코딩 배제)
 * ddm_product 테이블 구조 규격 매핑:
 * product_name (상품명), price (가격), description (설명), img_path (이미지경로), category (카테고리)
 */
$query = "SELECT * FROM ddm_product WHERE product_id = '$product_id'";
$result = mysqli_query($conn, $query);

// 데이터 검증 및 유무 판단
if ($result && mysqli_num_rows($result) > 0) {
    $product = mysqli_fetch_assoc($result);
} else {
    // 상품이 데이터베이스에 존재하지 않을 경우의 예외 처리
    echo "<script>alert('❌ 존재하지 않거나 판매가 중단된 상품입니다, 왈!'); location.href='shop_list.php';</script>";
    exit;
}
?>

<div class="container my-5">
    <div class="mb-4">
        <a href="shop_list.php" class="text-decoration-none text-muted small fw-bold">
            ⬅️ 상품 목록으로 돌아가기
        </a>
    </div>

    <div class="row g-5">
        
        <div class="col-md-6 text-center">
            <div class="card border-0 shadow-sm p-3" style="border-radius: 15px;">
                <img src="<?php echo htmlspecialchars($product['img_path']); ?>" 
                     onerror="this.src='https://via.placeholder.com/500x500/f3f0ff/6f42c1?text=DingDongDog'" 
                     class="img-fluid" 
                     style="border-radius: 12px; max-height: 500px; object-fit: cover;" 
                     alt="상품 이미지">
            </div>
        </div>

        <div class="col-md-6">
            <div class="p-2">
                <span class="badge mb-2 text-white px-3 py-2" style="background-color: #6f42c1; border-radius: 20px;">
                    <?php echo $product['category'] === 'feed' ? 'Bone 🦴 사료' : 'Soap 🧼 배변패드'; ?>
                </span>
                
                <h2 class="fw-bold mb-3 text-dark"><?php echo htmlspecialchars($product['product_name']); ?></h2>
                
                <h3 class="fw-bold mb-4" style="color: #6f42c1;">
                    <?php echo number_format($product['price']); ?><span class="small fs-5 text-secondary"> 원</span>
                </h3>
                
                <hr class="text-muted mb-4">

                <div class="mb-4">
                    <h6 class="fw-bold text-secondary mb-2">🐾 상품 요약 설명</h6>
                    <p class="text-muted lh-lg"><?php echo nl2br(htmlspecialchars($product['description'])); ?></p>
                </div>

                <form action="order_process.php" method="POST">
                    <input type="hidden" name="product_id" value="<?php echo htmlspecialchars($product_id); ?>">
                    <input type="hidden" name="product_price" value="<?php echo htmlspecialchars($product['price']); ?>">

                    <div class="row align-items-center mb-3">
                        <div class="col-4">
                            <label for="quantity" class="form-label text-secondary small fw-bold m-0">수량 선택</label>
                        </div>
                        <div class="col-8">
                            <input type="number" class="form-control" id="quantity" name="quantity" value="1" min="1" max="99" style="max-width: 100px; border-radius: 8px;">
                        </div>
                    </div>

                    <div class="row align-items-center mb-4">
                        <div class="col-4">
                            <label for="delivery_type" class="form-label text-secondary small fw-bold m-0">수령 방식</label>
                        </div>
                        <div class="col-8">
                            <select class="form-select" id="delivery_type" name="delivery_type" style="border-radius: 8px;">
                                <option value="direct">🚚 보호소 직접 택배 발송</option>
                                <option value="hq_pickup">🏢 본사 방문 수령</option>
                            </select>
                        </div>
                    </div>

                    <hr class="text-muted mb-4">

                    <div class="d-flex justify-content-between align-items-center mb-4 px-2">
                        <span class="fw-bold text-secondary">최종 합계 금액</span>
                        <span class="fw-bold fs-3 text-dark" id="total_price_display">
                            <?php echo number_format($product['price']); ?>원
                        </span>
                    </div>

                    <div class="row g-2">
                        <div class="col-sm-6">
                            <button type="submit" name="action" value="cart" class="btn btn-outline-dark w-100 p-3 fw-bold" style="border-radius: 10px; border-color: #6f42c1; color: #6f42c1;">
                                🛒 장바구니 담기
                            </button>
                        </div>
                        <div class="col-sm-6">
                            <button type="submit" name="action" value="direct_order" class="btn text-white w-100 p-3 fw-bold" style="background-color: #6f42c1; border-radius: 10px;">
                                ⚡ 즉시 결제하기
                            </button>
                        </div>
                    </div>
                </form>

            </div>
        </div>
    </div>
</div>

<script>
const pricePerItem = <?php echo intval($product['price']); ?>;
const qtyInput = document.getElementById('quantity');
const totalDisplay = document.getElementById('total_price_display');

qtyInput.addEventListener('input', function() {
    let qty = parseInt(this.value);
    if(isNaN(qty) || qty < 1) qty = 1;
    
    const totalPrice = pricePerItem * qty;
    totalDisplay.innerText = totalPrice.toLocaleString() + '원';
});
</script>

<?php
include 'footer.php'; // 공통 푸터 조립
?>
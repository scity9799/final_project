<?php
include 'db.php';
session_start();

$category = $_POST['product_category'];
$price = $_POST['product_price'];
$name = $_POST['product_name'];
$image_path = '';

// 🛑 [모의해킹 진단 포인트: File Upload 취약점 (웹쉘 주입)]
// 파일 확장자 화이트리스트 검사나 MIME-Type 체크가 전혀 없어, 공격자가 'webshell.php' 같은 
// 백도어 파일을 업로드하여 웹 서버 시스템 명령어를 원격 실행(RCE)할 수 있습니다.
if (isset($_FILES['product_image']) && $_FILES['product_image']['error'] == 0) {
    $upload_dir = 'uploads/';
    // 폴더가 없으면 자동 생성
    if(!is_dir($upload_dir)) { mkdir($upload_dir, 0777, true); }
    
    $file_name = $_FILES['product_image']['name'];
    $target_path = $upload_dir . $file_name;
    
    if (move_uploaded_file($_FILES['product_image']['tmp_name'], $target_path)) {
        $image_path = $target_path;
    }
}

$sql = "INSERT INTO ddm_product (product_category, product_name, product_price, product_image) 
        VALUES ('$category', '$name', $price, '$image_path')";
$result = mysqli_query($conn, $sql);

if ($result) {
    echo "<script>alert('새로운 상품이 성공적으로 상점에 등록되었습니다, 왈!'); location.href='shop_list.php';</script>";
} else {
    echo "<script>alert('DB 등록 중 에러가 발생했습니다.'); history.back();</script>";
}
?>
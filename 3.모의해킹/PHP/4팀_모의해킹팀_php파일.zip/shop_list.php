<?php
// 1. 공통 DB 연결 및 세션 시작 호출
include 'db.php'; 
include 'header.php'; 

// 2. 페이징 처리를 위한 핵심 변수 설정
$limit = 8; // 한 페이지에 보여줄 상품 개수 (요구사항: 8개)
$page = isset($_GET['page']) ? $_GET['page'] : 1; // 현재 페이지 번호 (기본값 1)

// [보안 진단 포인트] 실습 목적을 위해 입력값 검증(is_numeric 등)을 배제하여 
// page 파라미터를 통한 SQL Injection 훈련이 가능하도록 구성된 구역입니다.
$offset = ($page - 1) * $limit; 

// 3. 카테고리 필터링 변수 받기 (사료: feed / 배변패드: pad)
$category = isset($_GET['cate']) ? $_GET['cate'] : '';

// 4. 조건별 총 상품 개수(Total Row) 조회 쿼리 (페이이션 계산용)
$count_query = "SELECT COUNT(*) as total FROM ddm_product";
if (!empty($category)) {
    $count_query .= " WHERE product_category = '$category'";
}
$count_result = mysqli_query($conn, $count_query);
$count_row = mysqli_fetch_assoc($count_result);
$total_products = $count_row['total'];

// 총 페이지 수 계산
$total_pages = ceil($total_products / $limit);

// 5. 현재 페이지에 해당하는 데이터만 끊어 읽어오는 LIMIT 쿼리
$sql = "SELECT * FROM ddm_product";
if (!empty($category)) {
    $sql .= " WHERE product_category = '$category'";
}
$sql .= " ORDER BY product_id DESC LIMIT $offset, $limit";
$result = mysqli_query($conn, $sql);
?>

<div class="container my-5" style="min-height: 70vh;">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="text-dark fw-bold border-start border-4 border-indigo ps-2" style="border-color: #6f42c1 !important;">
            <?php 
                if($category == 'feed') echo "🐶 맛있는 영양 사료 목록";
                elseif($category == 'pad') echo "✨ 깔끔한 배변패드 목록";
                else echo "🛍️ 딩동몰 전체 상품 게시판";
            ?>
        </h3>
        <span class="text-muted">총 <?=$total_products?>개의 상품</span>
    </div>

    <div class="row row-cols-1 row-cols-md-2 row-cols-lg-4 g-4">
        <?php
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                // 더미 데이터나 DB 이미지 경로가 없을 경우를 대비한 기본 썸네일 처리
                $img_path = !empty($row['product_image']) ? $row['product_image'] : 'https://via.placeholder.com/300x300/f3f0ff/6f42c1?text=DingDongMall';
        ?>
                <div class="col">
                    <div class="card h-100 shadow-sm border-0 transition-hover" style="border-radius: 12px; overflow: hidden;">
                        <a href="shop_detail.php?id=<?=$row['product_id']?>">
                            <img src="<?=$img_path?>" class="card-img-top" alt="<?=$row['product_name']?>" style="height: 220px; object-fit: cover;">
                        </a>
                        <div class="card-body d-flex flex-column justify-content-between p-3">
                            <div>
                                <span class="badge mb-2" style="background-color: #ebe5fc; color: #6f42c1;">
                                    <?=$row['product_category'] == 'feed' ? '사료' : '배변패드'?>
                                </span>
                                <h5 class="card-title fw-bold text-dark mb-1" style="font-size: 1.05rem; overflow: hidden; text-overflow: ellipsis; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical;">
                                    <a href="shop_detail.php?id=<?=$row['product_id']?>" class="text-decoration-none text-dark">
                                        <?=htmlspecialchars($row['product_name'])?>
                                    </a>
                                </h5>
                            </div>
                            <div class="mt-3">
                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="fs-5 fw-bold text-danger"><?=number_format($row['product_price'])?>원</span>
                                    <a href="shop_detail.php?id=<?=$row['product_id']?>" class="btn btn-sm text-white px-3" style="background-color: #6f42c1; border-radius: 6px;">
                                        보기 🐾
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        <?php
            }
        } else {
            echo '<div class="col-12 text-center my-5 text-muted">등록된 상품이 없습니다, 왈! 🐶</div>';
        }
        ?>
    </div>

    <?php if ($total_pages > 1): ?>
        <nav aria-label="Page navigation" class="mt-5">
            <ul class="pagination justify-content-center">
                <li class="page-item <?=$page <= 1 ? 'disabled' : ''?>">
                    <a class="page-link" href="?cate=<?=$category?>&page=<?=$page-1?>" aria-label="Previous" style="color: #6f42c1;">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>

                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <li class="page-item <?=$page == $i ? 'active' : ''?>">
                        <a class="page-link" href="?cate=<?=$category?>&page=<?=$i?>" 
                           style="<?=$page == $i ? 'background-color: #6f42c1; border-color: #6f42c1; color: #fff;' : 'color: #6f42c1;'?>">
                            <?=$i?>
                        </a>
                    </li>
                <?php endfor; ?>

                <li class="page-item <?=$page >= $total_pages ? 'disabled' : ''?>">
                    <a class="page-link" href="?cate=<?=$category?>&page=<?=$page+1?>" aria-label="Next" style="color: #6f42c1;">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
            </ul>
        </nav>
    <?php endif; ?>
</div>

<style>
.transition-hover {
    transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
}
.transition-hover:hover {
    transform: translateY(-5px);
    box-shadow: 0 .5rem 1rem rgba(111, 66, 193, 0.15) !important;
}
</style>

<?php 
include 'footer.php'; 
?>
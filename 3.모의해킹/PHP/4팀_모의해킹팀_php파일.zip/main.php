<?php
// 1. 공통 DB 연결 호출
include 'db.php'; 

// 2. 리뉴얼된 공통 연보라색 상단 헤더 조립! (세션 시작 및 부트스트랩 인클루드 포함됨)
include 'header.php'; 

// 설정 파일 로드 (하드코딩 배제 설정 준수)
$config = parse_ini_file('config.ini');

// 구형 mysqli 방식으로 연결 (모의해킹 실습을 위해 에러 노출 소지가 있는 동적 쿼리 파이프라인 유지)
$conn = mysqli_connect($config['host'], $config['username'], $config['password'], $config['dbname']);
mysqli_set_charset($conn, "utf8mb4");

// [취약점 1] SQL Injection: 검색 키워드($keyword) 문자열 결합 필터링 부재 구역
$keyword = isset($_GET['keyword']) ? $_GET['keyword'] : '';

if (!empty($keyword)) {
    // 검색창에 ' UNION SELECT null, user_id, user_pw, null, null FROM ddd_user -- 등을 가공 주입하여 자산 유출 시연 가능
    $sql = "SELECT * FROM ddm_product WHERE product_name LIKE '%" . $keyword . "%'";
} else {
    // 요구사항: 메인 대문 8개 랜덤 무작위 상품 추출 (데이터 개수 8개 기준 제한)
    $sql = "SELECT * FROM ddm_product ORDER BY RAND() LIMIT 8";
}

$result = mysqli_query($conn, $sql);
?>

<div class="container my-5 text-center bg-white p-5 shadow-sm" style="border-radius: 16px;">
    <h2 class="fw-bold mb-2 text-dark">🐾 반려견을 위한 용품 검색</h2>
    <p class="text-muted small mb-4">딩동몰에서 사랑하는 반려견의 건강한 먹거리와 용품을 찾아보세요, 왈!</p>
    
    <?php if (!empty($keyword)): ?>
        <p class="text-indigo fw-bold">"<?=htmlspecialchars($keyword)?>" 검색 결과</p>
    <?php endif; ?>

    <form action="shop_list.php" method="GET" class="input-group w-50 mx-auto shadow-sm" style="border-radius: 8px; overflow: hidden;">
        <input type="text" name="keyword" class="form-control border-muted p-2" placeholder="상품명을 입력하세요..." style="border: 1px solid #e1dbf7;">
        <button class="btn text-white fw-bold px-4" type="submit" style="background-color: #6f42c1;">🔍 검색</button>
    </form>
</div>

<main class="container mb-5">
    <div class="row row-cols-1 row-cols-md-2 row-cols-lg-4 g-4">
        <?php 
        if (mysqli_num_rows($result) > 0):
            while($row = mysqli_fetch_assoc($result)): 
                // 테이블 명세서 스펙 변동 반영 (product_image, product_price)
                $img_path = !empty($row['product_image']) ? $row['product_image'] : 'https://via.placeholder.com/300x300/f3f0ff/6f42c1?text=DingDongMall';
        ?>
                <div class="col">
                    <div class="card h-100 border-0 shadow-sm transition-hover" style="border-radius: 12px; overflow: hidden; background-color: #fff;">
                        <a href="shop_detail.php?id=<?=$row['product_id']?>">
                            <img src="<?=$img_path?>" class="card-img-top" alt="<?=$row['product_name']?>" style="height: 200px; object-fit: cover;">
                        </a>
                        
                        <div class="card-body d-flex flex-column justify-content-between p-3">
                            <div>
                                <span class="badge mb-2" style="background-color: #ebe5fc; color: #6f42c1;">
                                    <?=$row['product_category'] == 'feed' ? '사료' : '배변패드'?>
                                </span>
                                <h6 class="card-title fw-bold text-dark mb-1" style="overflow: hidden; text-overflow: ellipsis; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; min-height: 2.4rem;">
                                    <a href="shop_detail.php?id=<?=$row['product_id']?>" class="text-decoration-none text-dark">
                                        <?=$row['product_name']?>
                                    </a>
                                </h6>
                            </div>
                            <div class="mt-3">
                                <div class="d-flex justify-content-between align-items-center">
                                    <span class="fs-5 fw-bold text-danger"><?=number_format($row['product_price'])?>원</span>
                                    <a href="shop_detail.php?id=<?=$row['product_id']?>" class="btn btn-sm text-white px-3" style="background-color: #6f42c1; border-radius: 6px;">
                                        보기 🦴
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php 
            endwhile; 
        else:
            echo '<div class="col-12 text-center my-5 text-muted">검색된 상품이 존재하지 않습니다, 왈! 🐶</div>';
        }
        ?>
    </div>
</main>

<style>
.transition-hover {
    transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
}
.transition-hover:hover {
    transform: translateY(-5px);
    box-shadow: 0 .5rem 1rem rgba(111, 66, 193, 0.15) !important;
}
</style>

<?php 
// 3. 리뉴얼된 공통 하단 푸터 조립!
include 'footer.php'; 
?>